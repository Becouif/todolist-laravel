
<?php $__env->startSection('content'); ?>

  <div class="container-fluid">
    <!-- breadcrumb start  -->
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="./">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Akojo</li>
    </ol>
    <!-- end of breadcrumb  -->

    <div>
      <?php if(Session::has('message')): ?>
        <div class="alert alert-success"><?php echo e(Session::has('message')); ?></div>
        
      <?php endif; ?>
    </div>
    <!-- start of form  -->

    <div class="card">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">View Collection|Wo Akojo</h6>
                </div>
                <div class="table-responsive">
                  <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                      <tr>
                        <th>ID</th>
                        <th>Lati se</th>
                        <th>Apejuwe</th>
                        <th>Akojo</th>
                        <th>-</th>
                        <th>-</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(is_countable($todoitems) && count($todoitems)>0): ?>
                      <?php $__currentLoopData = $todoitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$todoitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($todoitem->name); ?></td>
                        <td><?php echo $todoitem->description; ?></td>
                        
                        <td><?php echo e($todoitem->collection->name ?? 'None'); ?></td>
                        

                        <td><a href="<?php echo e(route('todoitem.edit',[$todoitem->id])); ?>"><button type="submit" class="btn btn-sm btn-secondary">Edit</button></a></td>
                        <td><form action="<?php echo e(route('todoitem.destroy',[$todoitem->id])); ?>" method="post"><?php echo csrf_field(); ?>
                          <?php echo e(method_field('DELETE')); ?>

                          <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?> 
                      <td><h6>No todo created yet| Ko si lati se ti o seda</h6></td>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
                <div class="card-footer"></div>
              </div>

        
   
  </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\program-files\htdocs\laravel\main-laravel\todolist-app\resources\views/todoitem/index.blade.php ENDPATH**/ ?>