 <!-- Footer -->
 <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>copyright &copy; <script> document.write(new Date().getFullYear()); </script> - developed by
              <b><a href="<?php echo e(route('todoitem.index')); ?>" target="_blank">EnrichDD</a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <script src="<?php echo e(asset('admin/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/ruang-admin.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/vendor/chart.js/Chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/demo/chart-area-demo.js')); ?>"></script>  

  <!-- include summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#summernote').summernote();
});
</script>
</body>

</html><?php /**PATH F:\program-files\htdocs\laravel\main-laravel\todolist-app\resources\views/layouts/footer.blade.php ENDPATH**/ ?>