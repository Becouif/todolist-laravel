<!-- header section  -->

<?php echo $__env->make('Components.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
    <!-- Sidebar -->
    <?php echo $__env->make('Components.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
        <?php echo $__env->make('Components.layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <?php echo $__env->yieldContent('content'); ?>
        <!---Container Fluid-->
      </div>
     <?php echo $__env->make('Components.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\program-files\htdocs\laravel\main-laravel\todolist-app\resources\views/Components/layouts/main.blade.php ENDPATH**/ ?>